let img;

function preload() {
  img = loadImage('bla.jpg');
}

function setup() {
createCanvas(270,700);
background(0)
  
}
function draw(){
  background(0);
  tint(255,0,0)
  image(img, 0, 0,img.width/2, img.height/2);
  noTint();
  image(img, 0, img.height/2,img.width/2, img.height/2);
}
