let img;
let levels = 3; // Adjust the number of levels here

function preload() {
  img = loadImage('ss.jpg');
}

function setup() {
  createCanvas(img.width, img.height);
  posterizeImage();
}

function posterizeImage() {
  img.filter(POSTERIZE, levels);
  image(img, 0, 0);
}
