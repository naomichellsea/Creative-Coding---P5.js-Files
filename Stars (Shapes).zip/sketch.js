function setup() {
  // Create the canvas
  createCanvas(600, 500);
  background('#fae');

  translate(300, 250);
  noStroke();
  for (let i = 0; i < 10; i ++) {
    ellipse(0, 30, 20, 80);
    rotate(PI/3);
    fill(255, 204, 0);
  }
   translate(200, 10);
  noStroke();
  for (let i = 0; i < 10; i ++) {
    ellipse(0, 30, 20, 80);
    rotate(PI/3);
    fill(255, 204, 0);
  }
  translate(200,0);
  noStroke();
  for (let i = 0; i < 10; i ++) {
    ellipse(0, 30, 20, 80);
    rotate(PI/3);
    fill(255, 204, 0);
  }
}
