var numFrames = 5
var frame = 0
var images = new Array(numFrames);
function preload() {
  images[0] = loadImage('n.jpg');
  images[1] = loadImage('v.jpg');
  images[2] = loadImage('z.jpg');
  images[3] = loadImage('b.jpg');
  images[4] = loadImage('m.jpg');
}
function setup() {
  createCanvas(600,600);
  frameRate(15);
  background (255);
}
function draw() {
  background(255);
  frame++;
  if (frame == numFrames) frame = 0;
  image(images[frame], mouseX - 75, mouseY - 100);
}