var img, x, y;

function preload() {
  img = loadImage('ss.jpg');
}

function setup() {
  createCanvas(800, 800);
  background(0);
}

function draw() {
  background(0);
  x = mouseX;
  y = mouseY;
  image(img, 0, 0);
  var c = get(x, y);
  fill(c);
  drawStar(x, y, 5, 50, 20); // Draw a star centered at (x, y)
}

function drawStar(x, y, numPoints, outerRadius, innerRadius) {
  var angle = TWO_PI / numPoints;
  var halfAngle = angle / 2.0;
  beginShape();
  for (var a = -PI / 2; a < TWO_PI - PI / 2; a += angle) {
    var sx = x + cos(a) * outerRadius;
    var sy = y + sin(a) * outerRadius;
    vertex(sx, sy);
    sx = x + cos(a + halfAngle) * innerRadius;
    sy = y + sin(a + halfAngle) * innerRadius;
    vertex(sx, sy);
  }
  endShape(CLOSE);
}
