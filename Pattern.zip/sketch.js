function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);

  var shapeSize = 40;
  var numShapesX = Math.ceil(width / shapeSize);
  var numShapesY = Math.ceil(height / shapeSize);
  var colorStep = 255 / (numShapesX * numShapesY);

  for (var x = 0; x < width; x += shapeSize) {
    for (var y = 0; y < height; y += shapeSize) {
      var fillColor;
      if ((x / shapeSize + y / shapeSize) % 2 === 0) {
        fillColor = color(255); // White
      } else {
        fillColor = color(139, 69, 19); // Brown
      }

      // Draw square or triangle based on position
      if ((x / shapeSize + y / shapeSize) % 2 === 0) {
        drawSquare(x, y, shapeSize, fillColor);
      } else {
        drawTriangle(x, y, shapeSize, fillColor);
      }
    }
  }
}

function drawSquare(x, y, size, fillColor) {
  fill(fillColor);
  rect(x, y, size, size);
}

function drawTriangle(x, y, size, fillColor) {
  fill(fillColor);
  beginShape();
  vertex(x, y);
  vertex(x + size, y);
  vertex(x + size / 2, y + size);
  endShape(CLOSE);
}
