var img, x, y;

function preload() {
  img = loadImage('cm.jpg');
}

function setup() {
  createCanvas(800, 800);
  background(0);
  noStroke();
}

function draw() {
  x = random(width);
  y = random(height);
  var c = img.get(x, y);
  fill(c[0], c[1], c[2], 300); // Adjust transparency here
  rectMode(CENTER); // Set the rectangle mode to center
  rect(x, y, 50, 50); // Draw a square
}
