function setup() {
  createCanvas(510, 570);
}

function draw() {
  background(110*cos(frameCount/22),110*sin(frameCount/32),200);

  // Calculate eye positions based on mouseX
  var leftEyeX = map(mouseX, 0, 400, 260, 165);
  var rightEyeX = map(mouseX, 0, 400, 140, 395);
  var eyeY = 120;

  // Head
  fill(250, 203, 22);
  rect(30, 20, 350, 300, 20);
  
  // Spots on the body
  fill(190, 143, 13);
  ellipse(105, 220, 20, 20);
  ellipse(155, 260, 15, 15);
  ellipse(80, 180, 20, 20);
  ellipse(250, 100, 20, 20);
  ellipse(280, 120, 20, 20);
  ellipse(300, 250, 20, 20);
  ellipse(320, 200, 25, 25);
  ellipse(350, 160, 15, 15);

  
  // Shirt
  fill(220);
  rect(30, 300, 350, 60);
  
  // Collar
  stroke(0);
  triangle(90, 300, 150, 300, 120, 350);
  triangle(240, 300, 300, 300, 270, 350);
  
  // Eyes
  // Whites
  fill(220);
  stroke(0);
  ellipse(leftEyeX, eyeY, 120, 90);
  ellipse(rightEyeX, eyeY, 120, 90);
  
  // Iris (change to blue)
  fill(0, 0, 255); // Blue color
  circle(leftEyeX, eyeY, 45);
  circle(rightEyeX, eyeY, 45);
  
  // Pupil
  fill(0);
  circle(leftEyeX, eyeY, 20);
  circle(rightEyeX, eyeY, 20);

  // Eyelashes
  drawEyelashes(leftEyeX, eyeY);
  drawEyelashes(rightEyeX, eyeY);

  // Pants
  fill(139, 69, 19);
  rect(30, 350, 350, 60);
  
  // Arms
  fill(250, 203, 22);
  rect(10, 200, 20, 100); // Left arm
  rect(370, 200, 20, 100); // Right arm
  
  // Tie
  noStroke();
  fill(250, 0, 0);
  triangle(180, 300, 220, 300, 200, 350);
  rect(190, 340, 20, 55);
  
  // Mouth
  fill(220, 20, 60);
  arc(200, 200, 120, 120, 0, PI);
  
  // Tongue
  fill(255, 192, 203);
  arc(200, 234, 60, 80, 0, PI);
  
  // Teeth
  fill(220);
  square(205, 200, 30);
  square(165, 200, 30);

  // Nose
  fill(255, 255, 0); // Yellow color
  stroke(0); // Black outline
  strokeWeight(2); // Outline thickness
  circle(205, 170, 20);

  // Legs
  noStroke();
  fill(250, 203, 22);
  rect(100, 400, 60, 30);
  rect(235, 400, 60, 30);
  
  // Exposed legs
  fill(250, 203, 22);
  rect(125, 430, 15, 50);
  rect(250, 430, 15, 50);
  
  // Socks
  fill(250);
  rect(125, 480, 15, 50);
  rect(250, 480, 15, 50);
  
  // Shoes
  fill(0);
  ellipse(125, 530, 60, 30);
  ellipse(265, 530, 60, 30);
  rect(136, 530, 20, 25);
  ellipse(100, 540, 60, 30);
  rect(235, 530, 20, 25);
  ellipse(285, 540, 60, 30);
}

function drawEyelashes(x, y) {
  // Draw eyelashes for an eye at position (x, y)
  stroke(0);
  strokeWeight(2);
  line(x - 40, y - 53, x - 30, y - 40);
  line(x - 20, y - 53, x - 10, y - 40);
  line(x + 20, y - 53, x + 10, y - 40);
}
