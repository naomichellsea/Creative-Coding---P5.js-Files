function setup() {
	// Set the canvas size
	createCanvas(160, 284); 
}

function draw() {
	// Set the background colour
	background(251, 236, 31);
	
	// Draw the Minion's overalls
	noStroke();
	fill(29, 118, 186);
	rect(0, 187.5, 160, 96.5); 

	// Draw the Minion's goggles
	fill(35);
	rect(0, 56.25, 160, 31.25); 
	fill(205);
	ellipse(54.375, 71.875, 60, 60); 
	ellipse(105.625, 71.875, 60, 60); 
	// Draw the Minion's buttons
	fill(35);
	ellipse(12.5, 200, 12.5, 12.5); 
	ellipse(147.5, 200, 12.5, 12.5); 
	fill(55);
	ellipse(12.5, 200, 10, 10); 
	ellipse(147.5, 200, 10, 10); 
	stroke(35);
	strokeWeight(0.625); 
	line(12.5, 196.25, 12.5, 203.75); 
	line(9.375, 200, 15.625, 200); 
	line(147.5, 196.25, 147.5, 203.75); 
	line(144.375, 200, 150.625, 200); 

	// Draw the G logo
	noStroke();
	fill(14, 55, 86);
	ellipse(80, 237.5, 50, 62.5); 
	fill(29, 118, 186);
	beginShape();
	vertex(80, 207.5); 
	vertex(56.25, 237.5); 
	vertex(80, 262.5); 
	vertex(103.75, 237.5); 
	endShape();
	fill(14, 55, 86);
	ellipse(80, 237.5, 25, 35); 
	rect(80, 235, 25, 2.5); 
	fill(29, 118, 186);
	rect(85, 237.5, 10, 2.5); 


	// Draw the Minion's eyes
	fill(255);
	ellipse(54.375, 71.875, 46.25, 46.25); 
	ellipse(105.625, 71.875, 46.25, 46.25); 
	fill(137, 93, 58);
	ellipse(54.375, 71.875, 25, 25); 
	ellipse(105.625, 71.875, 25, 25); 
	fill(0);
	ellipse(54.375, 71.875, 12.5, 12.5); 
	ellipse(105.625, 71.875, 12.5, 12.5); 
	fill(255);
	ellipse(50.625, 68.125, 6.25, 6.25); 
	ellipse(101.875, 68.125, 6.25, 6.25); 

	// Draw the Minion's smile
	stroke(0);
	strokeWeight(1.25); 
	noFill();
	arc(68.75, 125, 87.5, 62.5, 0, 2); 
}

