let img;

function preload() {
  img = loadImage('ff.jpg');
}

function setup() {
  createCanvas(img.width, img.height);
  image(img, 0, 0);
  invertImage();
}

function invertImage() {
  loadPixels();
  for (let i = 0; i < pixels.length; i += 4) {
    pixels[i] = 255 - pixels[i]; // Red
    pixels[i + 1] = 255 - pixels[i + 1]; // Green
    pixels[i + 2] = 255 - pixels[i + 2]; // Blue
  }
  updatePixels();
}
