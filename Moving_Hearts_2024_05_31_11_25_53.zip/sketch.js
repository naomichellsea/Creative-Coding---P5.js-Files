let hearts = [];

function setup() {
  createCanvas(400, 400);
  colorMode(HSB, 360, 100, 100);
  for (let i = 0; i < 100; i++) {
    hearts.push(new Heart(random(width), random(height), random(20, 100), color(random(360), 100, 100), random(-2, 2), random(-2, 2)));
  }
}

function draw() {
  background(0);
  for (let heart of hearts) {
    heart.move();
    heart.display();
  }
}

class Heart {
  constructor(x, y, size, color, speedX, speedY) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.color = color;
    this.speedX = speedX;
    this.speedY = speedY;
  }

  display() {
    fill(this.color);
    noStroke();
    beginShape();
    vertex(this.x, this.y + this.size / 4);
    bezierVertex(this.x + this.size / 2, this.y - this.size / 2, this.x + this.size, this.y + this.size / 5, this.x, this.y + this.size);
    bezierVertex(this.x - this.size, this.y + this.size / 5, this.x - this.size / 2, this.y - this.size / 2, this.x, this.y + this.size / 4);
    endShape(CLOSE);
  }

  move() {
    this.x += this.speedX;
    this.y += this.speedY;

    if (this.x < 0 || this.x > width) {
      this.speedX *= -1;
    }

    if (this.y < 0 || this.y > height) {
      this.speedY *= -1;
    }
  }
}
