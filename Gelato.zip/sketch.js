let detailY;

function setup() {
  createCanvas(400, 400, WEBGL);
  detailY = createSlider(3, 16, 3);
  detailY.position(10, height + 5);
  detailY.style('width', '80px');
}

function draw() {
  background(255, 204, 0);
  
  // Draw cone
  cone(30, 65, 16, detailY.value());
  rotateY(millis() / 1000);
  
  // Draw ice cream scoop
  translate(0, -50); 
  fill(255, 200, 200); // Light pink color for ice cream
  sphere(30); 
  
  translate(0, -15); // Move to the top of the sphere
  for (let i = 0; i < 5; i++) {
    let angle = map(i, 0, 4, 0, TWO_PI); 
    let x = 20 * cos(angle); 
    let z = 20 * sin(angle); 
    push(); 
    translate(x, 0, z); // Move to the position
    rotateX(HALF_PI); 
    fill(92, 51, 23); // Brown color for chocolate
    cylinder(5, 15); 
    pop(); 
  }
  

  translate(0, -20); 
  fill(255, 0, 0); // Red color for cherries
  for (let i = 0; i < 3; i++) {
    let angle = map(i, 0, 2, 0, TWO_PI); 
    let x = 25 * cos(angle); // Calculate x-coordinate
    let z = 25 * sin(angle); // Calculate z-coordinate
    translate(x, 0, z); 
    sphere(7); 
  }
}
