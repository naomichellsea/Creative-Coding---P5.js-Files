let song;
let fft;
let particles = [];

function preload() {
  song = loadSound('Disney Intro Full HD 1080p.mp3'); // Replace with your audio file path
}

function setup() {
  createCanvas(windowWidth, windowHeight);
  angleMode(DEGREES);
  fft = new p5.FFT();
  song.loop();

  for (let i = 0; i < 300; i++) {
    particles.push(new Particle());
  }
}

function draw() {
  background(10, 10, 30, 100);

  let spectrum = fft.analyze();
  let waveform = fft.waveform();

  translate(width / 2, height / 2);

  stroke(255);
  noFill();

  // Heart shape outline visualization
  strokeWeight(2);
  beginShape();
  for (let i = 0; i < 360; i++) {
    let theta = i;
    let amp = spectrum[floor(map(i, 0, 360, 0, spectrum.length))];
    let r = map(amp, 0, 256, 5, 15); // Increased the scaling factor for a much bigger heart
    let x = r * 16 * pow(sin(theta), 3);
    let y = -r * (13 * cos(theta) - 5 * cos(2 * theta) - 2 * cos(3 * theta) - cos(4 * theta));
    vertex(x, y);
  }
  endShape(CLOSE);

  // Glowing effect
  push();
  drawingContext.shadowBlur = 20;
  drawingContext.shadowColor = color(255, 255, 255);
  beginShape();
  for (let i = 0; i < 360; i++) {
    let theta = i;
    let amp = spectrum[floor(map(i, 0, 360, 0, spectrum.length))];
    let r = map(amp, 0, 256, 5, 15); // Increased the scaling factor for a much bigger heart
    let x = r * 16 * pow(sin(theta), 3);
    let y = -r * (13 * cos(theta) - 5 * cos(2 * theta) - 2 * cos(3 * theta) - cos(4 * theta));
    vertex(x, y);
  }
  endShape(CLOSE);
  pop();

  // Particle system
  for (let i = particles.length - 1; i >= 0; i--) {
    particles[i].update();
    particles[i].show();

    if (particles[i].edges()) {
      particles.splice(i, 1);
      particles.push(new Particle());
    }
  }
}

class Particle {
  constructor() {
    this.pos = p5.Vector.random2D().mult(random(100, 300));
    this.vel = createVector(0, 0);
    this.acc = this.pos.copy().mult(random(0.0001, 0.00001));
    this.w = random(2, 5);

    this.color = [random(0, 255), random(0, 255), random(100, 255), random(150, 255)];
  }

  update() {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
  }

  edges() {
    if (this.pos.x > width / 2 || this.pos.x < -width / 2 || this.pos.y > height / 2 || this.pos.y < -height / 2) {
      return true;
    }
    return false;
  }

  show() {
    noStroke();
    fill(this.color);
    ellipse(this.pos.x, this.pos.y, this.w);
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}
