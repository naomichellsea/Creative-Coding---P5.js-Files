let trails = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  // Create a gradient background
  setGradient(0, 0, width, height, color(0, 0, 128), color(255, 0, 128), 'Y');
  
  // Add new trail at the mouse position
  trails.push(new Trail(mouseX, mouseY));
  
  // Update and display all trails
  for (let i = trails.length - 1; i >= 0; i--) {
    trails[i].update();
    trails[i].show();
    
    // Remove the trail if it's faded out completely
    if (trails[i].alpha <= 0) {
      trails.splice(i, 1);
    }
  }
}

class Trail {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = random(10, 50);
    this.alpha = 255;
    this.color = color(random(255), random(255), random(255));
  }
  
  update() {
    // Reduce alpha to create fading effect
    this.alpha -= 5;
  }
  
  show() {
    noStroke();
    fill(red(this.color), green(this.color), blue(this.color), this.alpha);
    drawHeart(this.x, this.y, this.size);
  }
}

// Function to draw a heart shape
function drawHeart(x, y, size) {
  beginShape();
  vertex(x, y + size / 4);
  bezierVertex(x - size / 2, y - size / 2, x - size, y + size / 4, x, y + size);
  bezierVertex(x + size, y + size / 4, x + size / 2, y - size / 2, x, y + size / 4);
  endShape(CLOSE);
}

// Function to create a gradient background
function setGradient(x, y, w, h, c1, c2, axis) {
  noFill();
  
  if (axis === 'Y') {
    for (let i = y; i <= y + h; i++) {
      let inter = map(i, y, y + h, 0, 1);
      let c = lerpColor(c1, c2, inter);
      stroke(c);
      line(x, i, x + w, i);
    }
  } else if (axis === 'X') {
    for (let i = x; i <= x + w; i++) {
      let inter = map(i, x, x + w, 0, 1);
      let c = lerpColor(c1, c2, inter);
      stroke(c);
      line(i, y, i, y + h);
    }
  }
}
