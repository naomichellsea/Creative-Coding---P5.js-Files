let img;

function preload() {
  img = loadImage('ww.jpg');
}

function setup() {
  createCanvas(600, 600);
  image(img, 0, 0);
  filter(BLUR, 5);
}
