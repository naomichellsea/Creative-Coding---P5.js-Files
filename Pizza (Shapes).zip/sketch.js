function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(255, 204, 0)
  circle(250,250,300);
  describe('A pink circle on a yellow canvas');
  triangle(250,250,200,150,150,200);
  fill(204, 101, 192, 127);
  stroke(127, 63, 120);
 
 
 
}