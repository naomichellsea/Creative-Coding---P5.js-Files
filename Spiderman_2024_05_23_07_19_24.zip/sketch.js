function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  
   print(mouseX, mouseY)
  
  //blue background
  background(75, 104, 191);
  
  

//spiderman head
  
  fill(222, 2, 2)
  ellipse(200, 200, 185, 255)
  
  
  //lines on face
  strokeWeight(2.5)
  line(200, 74, 200, 230)
  line(120, 135, 190, 230)
  line(280, 135, 210, 230)
  line(260, 294, 210, 250)
  line(140, 294, 190, 250)
  line(175, 320, 195, 250)
  line(230, 320, 205, 250)
  
  
  
  //left eye
fill(255, 255,255)
  arc(150, 200, 80, 80, 0, PI + QUARTER_PI, CHORD);
  
  
  fill(255, 255, 255);
  arc(250, 160, 85, 160, 0.3, PI - QUARTER_PI, CHORD);


  
}