let barData = [];
let pieData = [];
let pieColors = [];
let pieHoverIndex = -1;
let rotationAngle = 0;
let circles = [];

function setup() {
  createCanvas(800, 600);

  // Generate random data for both charts
  for (let i = 0; i < 5; i++) {
    barData.push(random(20, 200));
    pieData.push(random(10, 100));
    pieColors.push(color(random(255), random(255), random(255)));
  }

  // Create circles for background animation
  for (let i = 0; i < 100; i++) {
    circles.push(new Circle());
  }
}

function draw() {
  // Draw animated background
  drawBackground();

  // Draw bar chart
  drawBarChart(100, 100, 600, 400, barData);

  // Draw pie chart
  drawPieChart(500, 300, 200, pieData, pieColors);
}

function drawBackground() {
  background(240);

  for (let i = 0; i < circles.length; i++) {
    circles[i].move();
    circles[i].display();
  }
}

class Circle {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.diameter = random(10, 30);
    this.speedX = random(-1, 1);
    this.speedY = random(-1, 1);
    this.color = color(random(255), random(255), random(255), 100);
  }

  move() {
    this.x += this.speedX;
    this.y += this.speedY;

    if (this.x < 0 || this.x > width) {
      this.speedX *= -1;
    }

    if (this.y < 0 || this.y > height) {
      this.speedY *= -1;
    }
  }

  display() {
    fill(this.color);
    ellipse(this.x, this.y, this.diameter);
  }
}

function drawBarChart(x, y, w, h, data) {
  let barWidth = w / data.length;

  for (let i = 0; i < data.length; i++) {
    let barHeight = map(data[i], 0, max(barData), 0, h);
    let barColor = lerpColor(color(255, 0, 0), color(0, 0, 255), i / data.length);
    fill(barColor);
    rect(x + i * barWidth, y + h - barHeight, barWidth - 2, barHeight);
  }
}

function drawPieChart(x, y, d, data, colors) {
  let angle = rotationAngle;
  let total = sum(data);

  for (let i = 0; i < data.length; i++) {
    let segmentAngle = map(data[i], 0, total, 0, TWO_PI);
    let halfAngle = angle + segmentAngle / 2;

    // Draw pie segment
    let gradientColor = lerpColor(colors[i], color(255), 0.5); // Add gradient effect
    fill(gradientColor);
    if (i === pieHoverIndex) {
      fill(gradientColor.levels.map(c => c * 0.8)); // Darken color on hover
    }
    arc(x, y, d, d, angle, angle + segmentAngle, PIE);

    // Draw label
    let labelX = x + cos(halfAngle) * d * 0.4;
    let labelY = y + sin(halfAngle) * d * 0.4;
    textAlign(CENTER, CENTER);
    textSize(16);
    fill(0);
    text(round((data[i] / total) * 100) + "%", labelX, labelY);

    angle += segmentAngle;
  }
}

function mouseMoved() {
  console.log("Hey! :>> Mouse is moving <3!"); // Check if the function is called

  let pieDiameter = 200;
  let pieX = 500;
  let pieY = 300;
  let d = dist(mouseX, mouseY, pieX, pieY);

  if (d < pieDiameter / 2) {
    let angle = atan2(mouseY - pieY, mouseX - pieX);
    let segment = floor(map(angle + PI / 2 - rotationAngle, 0, TWO_PI, 0, pieData.length));
    pieHoverIndex = constrain(segment, 0, pieData.length - 1);
  } else {
    pieHoverIndex = -1;
  }
}

function keyPressed() {
  if (key === 'a' || key === 'A') {
    rotationAngle -= 0.1; // Rotate counterclockwise
  } else if (key === 'd' || key === 'D') {
    rotationAngle += 0.1; // Rotate clockwise
  }
}
