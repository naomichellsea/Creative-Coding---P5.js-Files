let player;
let obstacles = [];
let score = 0;
let interval = 60; // Interval between obstacle spawns
let speedIncrease = 0.05; // Speed increase factor
let obstacleSpeed = 3; // Initial obstacle speed
let gameOver = false;
let backgroundMusic;
let amp;
let bgColor;

function preload() {
  backgroundMusic = loadSound('Wii Music - Gaming Background Music (HD).mp3');
}

function setup() {
  createCanvas(600, 400);
  player = new Player();
  textAlign(CENTER);

  // Start playing the background music
  backgroundMusic.loop();

  // Create an amplitude object
  amp = new p5.Amplitude();
}

function draw() {
  // Get the current amplitude level of the music
  let level = amp.getLevel();

  // Adjust the background color based on the amplitude level
  let pinkValue = map(level, 0, 1, 200, 255);
  bgColor = color(255, pinkValue, pinkValue);

  // Set the background color
  background(bgColor);

  if (!gameOver) {
    if (frameCount % interval === 0) {
      obstacles.push(new Obstacle());
      interval = Math.floor(random(30, 90));
    }

    player.display();
    player.update();

    for (let i = obstacles.length - 1; i >= 0; i--) {
      obstacles[i].display();
      obstacles[i].update();

      if (player.hits(obstacles[i])) {
        gameOver = true;
        break;
      }

      if (obstacles[i].passed(player)) {
        score++;
        obstacles.splice(i, 1);
        if (score % 5 === 0) {
          obstacleSpeed += speedIncrease;
        }
      }
    }

    textSize(20);
    fill(255);
    text("Score: " + score, width / 2, 30);
  } else {
    textSize(32);
    fill(255, 0, 0);
    text("Game Over", width / 2, height / 2);
    textSize(20);
    text("Press 'R' to restart", width / 2, height / 2 + 50);

    // Stop the background music when the game is over
    backgroundMusic.stop();
  }
}

function keyPressed() {
  if (key === ' ') {
    player.changeColor();
  } else if (key === 'r' || key === 'R') {
    restart();
  }
}

function restart() {
  obstacles = [];
  score = 0;
  gameOver = false;
  obstacleSpeed = 3;
  interval = 60;
  player.reset();

  // Start playing the background music again
  backgroundMusic.loop();
}

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
    this.size = 30;
    this.color = color(255, 0, 0); // Initial color is red
  }

  display() {
    fill(this.color);
    rectMode(CENTER);
    rect(this.x, this.y, this.size, this.size);
  }

  update() {
    if (keyIsDown(LEFT_ARROW) && this.x > 0) {
      this.x -= 5;
    } else if (keyIsDown(RIGHT_ARROW) && this.x < width) {
      this.x += 5;
    }
  }

  changeColor() {
    if (this.color === color(255, 0, 0)) {
      this.color = color(0, 255, 0); // Change to green
    } else {
      this.color = color(255, 0, 0); // Change to red
    }
  }

  hits(obstacle) {
    return (
      this.x - this.size / 2 < obstacle.x + obstacle.width / 2 &&
      this.x + this.size / 2 > obstacle.x - obstacle.width / 2 &&
      this.y - this.size / 2 < obstacle.y + obstacle.height / 2 &&
      this.y + this.size / 2 > obstacle.y - obstacle.height / 2 &&
      !obstacle.passed(this)
    );
  }

  reset() {
    this.x = width / 2;
    this.y = height - 50;
    this.color = color(255, 0, 0);
  }
}

class Obstacle {
  constructor() {
    this.x = random(width);
    this.y = -30;
    this.width = random(40, 80);
    this.height = 20;
    this.color = color(random(200, 255), random(200, 255), random(200, 255));
    this.speed = obstacleSpeed;
  }

  display() {
    fill(this.color);
    rectMode(CENTER);
    rect(this.x, this.y, this.width, this.height);
  }

  update() {
    this.y += this.speed;
  }

  passed(player) {
    return this.y > player.y + player.size / 2;
  }
}
