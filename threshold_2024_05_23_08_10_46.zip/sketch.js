let img;
let thresholdValue = 128;

function preload() {
  img = loadImage('pp.jpg');
}

function setup() {
  createCanvas(img.width, img.height);
  image(img, 0, 0);
}

function draw() {
  // Display the image
  image(img, 0, 0);

  // Apply threshold filter
  applyThreshold();
}

function applyThreshold() {
  // Update threshold value based on mouse position
  let threshold = map(mouseX, 0, width, 0, 1);

  // Apply threshold filter
  filter(THRESHOLD, threshold);
}
